/* eslint-disable jsx-a11y/label-has-for */
import React from "react";
import { Card, CardBody, Col, Row } from "reactstrap";
import CheckIcon from "mdi-react/CheckIcon";
import PropTypes from "prop-types";
// import '@vaadin/vaadin-grid/vaadin-grid.js'
import "@vaadin/vaadin-button";
import "@vaadin/vaadin-grid";
import "@vaadin/vaadin-text-field";
import { de } from "date-fns/esm/locale";
import ProfileTabs from './ProfileTabs';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import {
  addProfile,
  deleteProfile,
  updateProfile,
  selectedProf
} from "../../../../redux/actions/profileActions";
import ProfileList from './ProfileList'
const CheckBox = ({ checked }) => (
  <label
    htmlFor="profile-task-id"
    className="checkbox-btn profile__current-task-checkbox"
  >
    <input
      id="profile-task-id"
      className="checkbox-btn__checkbox"
      type="checkbox"
      defaultChecked={checked}
    />
    <span className="checkbox-btn__checkbox-custom">
      <CheckIcon />
    </span>
  </label>
);

CheckBox.propTypes = {
  checked: PropTypes.bool
};

CheckBox.defaultProps = {
  checked: false
};

class ProfileTasks extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      itemSelected: {},
      isSelected: false
    };
  }
  addNewProfile = () => {
    this.props.addProfile({
      id:
        Math.max(
          ...this.props.profileList.map(function(o) {
            return o.id;
          })
        ) + 1,
      name: "",
      email: "",
      company:{name: ""}
    });
  }
  loadClient = (profile)=> {
    // API call here
    debugger
    this.props.selectedProf(profile)
   }
  deleteProfile = (id) => {
    let r = window.confirm("Do you want to delete this item");
    if (r === true) {
      this.props.deleteProfile(id);
    }
  }
  editProfileSubmit = (id, name, email, company) => {
    this.props.updateProfile({
      id: id,
      name: name,
      email: email,
      company:{name: company}
    });
  }

  selectedProfile = (profile) => {
    this.setState({itemSelected: profile,isSelected: !this.state.isSelected})
  }

  render() {
    const checkSelected = Object.keys(this.state.itemSelected).length !== 0
    return (
      <Row>
        <Col md={12} lg={12} xl={4}>
          <Row>
            <Col md={12} lg={12} xl={12}>
              <Card>
                <CardBody className="profile__card">
                  {/* <vaadin-grid ref="grid">
                    <vaadin-grid-column path="firstName" header="First name" />
                    <vaadin-grid-column path="lastName" header="Last name" />
                  </vaadin-grid> */}
                  <table className="table table-hover">
                    <thead className="thead-dark">
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        {/* <th>Company</th>
                        <th>Edit/Save</th>
                        <th>Delete</th> */}
                      </tr>
                    </thead>
                    <ProfileList
                      deleteProfile={this.deleteProfile}
                      profileList={this.props.profileList}
                      editProfileSubmit={this.editProfileSubmit}
                      selectedProfile={this.selectedProfile}
                    />
                  </table>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Col>
        {checkSelected && <ProfileTabs profile={this.state.itemSelected} editProfileSubmit={this.editProfileSubmit} />}
      </Row>
    );
  }
}
const mapStateToProps = state => {
  return {
    profileList: state.profileData
  };
};
const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      addProfile: addProfile,
      deleteProfile: deleteProfile,
      updateProfile: updateProfile
    },
    dispatch
  );
};
export default connect(mapStateToProps,mapDispatchToProps)(ProfileTasks);
// connect(mapStateToProps,mapDispatchToProps)(App);
