import React, { Component } from "react";
import ProfileTabs from "./ProfileTabs";

export default class ProfileItem extends Component {
  constructor(props) {
    super(props);
    this.state = { isEdit: false };
    this.editProfile = this.editProfile.bind(this);
    this.editProfileSubmit = this.editProfileSubmit.bind(this);
    this.deleteProfile = this.deleteProfile.bind(this);
  }
  deleteProfile() {
    const { id } = this.props.profile;
    this.props.deleteProfile(id);
  }
  editProfile() {
    this.setState((prevState, props) => ({
      isEdit: !prevState.isEdit
    }));
  }
  editProfileSubmit() {
    this.setState((prevState, props) => ({
      isEdit: !prevState.isEdit
    }));
    debugger
    this.props.editProfileSubmit(
      this.props.profile.id,
      this.nameInput.value,
      this.gradeInput.value,
      this.schoolInput.value
    );
  }
  handleClick(item){
      debugger
    // const { selectedId } = this.props.profile;
    this.props.selectedProfile(this.props.profile);
  }
  render() {
    const { name, email, company } = this.props.profile;
    return this.state.isEdit === true ? (
      <tr className="bg-warning" key={this.props.index}  onClick={this.handleClick}>
        <td>
          <input
            ref={nameInput => (this.nameInput = nameInput)}
            defaultValue={name}
          />
        </td>
        <td>
          <input
            defaultValue={email}
            ref={gradeInput => (this.gradeInput = gradeInput)}
          />
        </td>
        <td>
          <input
            ref={schoolInput => (this.schoolInput = schoolInput)}
            defaultValue={company.name}
          />
        </td>
        <td>
          <i className="sidebar__link-icon lnr lnr-checkmark-circle" onClick={this.editProfileSubmit}></i>
        </td>
        <td>
          <i className="sidebar__link-icon lnr lnr-trash"></i>
        </td>
      </tr>
    ) : (
      <tr key={this.props.index} onClick={this.handleClick.bind(this,this.props.profile)}>
        <td>{name}</td>
        <td>{email}</td>
        {/* <td>{company.name}</td>
        <td>  
          <i className="sidebar__link-icon lnr lnr-pencil" onClick={this.editProfile}></i>
        </td>
        <td>
          <i className="sidebar__link-icon lnr lnr-trash" onClick={this.deleteProfile}></i>
        </td> */}
      </tr>
    );
  }
}
