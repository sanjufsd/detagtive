
import React, { PureComponent } from 'react';
import {
    Card, CardBody, Col, Button,ButtonToolbar
  } from 'reactstrap';
  import { withTranslation } from 'react-i18next';
  import { Field, reduxForm } from 'redux-form';
const Ava = `${process.env.PUBLIC_URL}/img/12.png`;

class ProfileTabs extends PureComponent {
  constructor(props) {
    super(props);

    // this.toggle = this.toggle.bind(this);
    this.state = {
      editAble: false,
    };
  }

componentDidMount(){
  debugger
  // this.props.loadClient(this.props.profile);
}

  editProfile() {
    debugger
    this.setState((prevState, props) => ({
      editAble: !prevState.editAble
    }));
  }
  // editProfileSubmit() {
  //   this.setState((prevState, props) => ({
  //     isEdit: !prevState.isEdit
  //   }));
  //   debugger
  //   this.props.editProfileSubmit(
  //     this.props.profile.id,
  //     this.nameInput.value,
  //     this.gradeInput.value,
  //     this.schoolInput.value
  //   );
  // }
  render() {
    const proValues = this.props.profile
    const initialValues = {
      name: proValues.name,
      email: proValues.email,
      phone: proValues.phone,
      company: proValues.company.name
    };
    const editAble = this.state.editAble
    console.log("props::",this.props)

    const { activeTab } = this.state;


    return (
      <Col md={12} lg={12} xl={8}>
        <Card>
          <div className="profile__card tabs tabs--bordered-bottom">
            <div className="tabs__wrap">
              
            <Col md={12} lg={12} xl={12}>
    <Card>
      <CardBody className="profile__card">
        <div className="profile__information">
          <div className="profile__avatar">
            <img src={Ava} alt="avatar" />
          </div>
          <div className="profile__data">
            <p className="profile__name">{initialValues.name}</p>
          </div>
        </div>
        
          <i className="sidebar__link-icon lnr lnr-pencil" onClick={this.editProfile.bind(this)}></i>
        
          {/* <i className="sidebar__link-icon lnr lnr-trash" onClick={this.deleteProfile}></i> */}
        
      </CardBody>
      <form className="form" >
      <div className="form__half">
        <div className="form__form-group">
          <span className="form__form-group-label">Name</span>
          <div className="form__form-group-field">
          {editAble ? 
            <Field
              name="name"
              component="input"
              type="text"
              value={initialValues.name}
              placeholder="Name"
            /> : initialValues.name}
          </div>
        </div>
        <div className="form__form-group">
          <span className="form__form-group-label">Company</span>
          <div className="form__form-group-field">
          {editAble ? 
            <Field
              name="company"
              component="input"
              type="text"
              value={initialValues.company}
              placeholder="Last Name"
            /> : initialValues.company}
          </div>
        </div>
        <div className="form__form-group">
          <span className="form__form-group-label">E-mail</span>
          <div className="form__form-group-field">
          { editAble ? 
           
            <Field
              name="email"
              component="input"
              type="text"
              value={initialValues.email}
              placeholder="name@example.com"
            /> : initialValues.email}
          </div>
        </div>

      </div>
      <div className="form__half">

        <div className="form__form-group">
          <span className="form__form-group-label">Phone</span>
          <div className="form__form-group-field">
          {initialValues.phone}
          {editAble ?
            <Field
              name="phone"
              component="input"
              type="text"
              value={initialValues.phone}
              placeholder="999-999-99999"
            /> : initialValues.phone}
          </div>
        </div>
        {editAble && 
        <ButtonToolbar className="form__button-toolbar">
          <Button type="button" >
                Cancel
          </Button>
          <Button color="primary" type="submit">Submit</Button>
        </ButtonToolbar>
        }
      </div>
    </form>
    </Card>
  </Col>



 
            </div>
          </div>
        </Card>
      </Col>
    );
  }
}
const mapStateToProps = (state, props) => ({
  initialValues: state, // retrieve name from redux store 
})

export default reduxForm({
  form: 'vertical_form_layout_half'
 
  
})(withTranslation('common')(ProfileTabs));
// connect(state => ({
//   initialValues: state // load the saved data here
// }),
// { loadClient }
// )