/* eslint-disable jsx-a11y/img-redundant-alt */
import React from "react";
import { userFormMetaData } from "./data";
import { FormGroup, Label, Input, Col } from "reactstrap";
import {
  FaPen,
  FaCheckCircle,
  FaTimesCircle,
  FaChevronDown,
  FaChevronUp,
  FaGlobeAmericas,
  FaUserAlt
} from "react-icons/fa";
import { Accordion, Card } from "react-bootstrap";

const defaultAnswers = {
  Title: "Mr",
  Name: "",
  Surname: "",
  "Phone number": "",
  Department: "",
  Email: "",
  Client: "C1",
  Language: "English",
  Timezone: "UTC"
};
export default class ProfileDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userDetails: props.userDetails,
      mode: props.mode,
      answers: defaultAnswers,
      updateAnswers: false
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
      console.log("inside getDerived..", nextProps.mode)
      console.log("inside getDerived..", prevState.mode)
      console.log("props",nextProps.mounted)
      if((prevState.mode !== 'edit' || nextProps.userDetails.id!==prevState.userDetails.id)){
        return {
            userDetails: nextProps.userDetails,
            mode: nextProps.mode,
            updateAnswers: true
          };
      }
  }
  buildAnswers = () => {
    console.log("inside build answers...");
    if (this.state.mode === "show" || this.state.mode === "edit") {
      let answers = defaultAnswers;
      let keys = Object.keys(answers);
      keys.forEach(val => {
        answers[val] = this.state.userDetails[val];
      });
      console.log("answers is :: ", answers);
      this.setState({ updateAnswers: true, answers });
    }
  };
  handleInputChange = (event, obj) => {
    let answers = this.state.answers;
    answers[obj.label] = event.target.value;
    this.setState({ answers, updateAnswers: false });
    console.log(answers);
  };

  handleDropDownChange = (event, obj) => {
    let answers = this.state.answers;
    answers[obj.label] = event.target.value;
    this.setState({ answers, updateAnswers: false });
  };

  getFormInput = obj => {
    let renderProfile = {}
    debugger
    renderProfile = this.state.mode === "create" ? this.props.userDetails : this.state.answers
    if (obj.type === "text") {
      console.log('answers data::',this.state.answers)
      return (
        <FormGroup row>
          <Label for={obj.label} sm={2}>
            {obj.label}
          </Label>
          <Col sm={10}>
            {this.state.mode === "show" ? (
              <div className="user-values">{renderProfile[obj.label]}</div>
            ) : (
              <Input
                type="text"
                name={obj.label}
                id={obj.id}
                placeholder={obj.placeHolder}
                defaultValue={renderProfile[obj.label]}
                onChange={e => this.handleInputChange(e, obj)}
              />
            )}
          </Col>
        </FormGroup>
      );
    } else if (obj.type === "dropdown") {
      let values = obj.values.map(val => <option>{val}</option>);
      return (
        <FormGroup row>
          <Label for={obj.label} sm={2}>
            {obj.label}
          </Label>
          <Col sm={10}>
            {this.state.mode === "show" ? (
             <div className="user-values">{ renderProfile[obj.label]}</div>
            ) : (
              <Input
                type="select"
                name={obj.label}
                id={obj.id}
                onChange={e => this.handleDropDownChange(e, obj)}
                defaultValue={renderProfile[obj.label]}
              >
                {values}
              </Input>
            )}
          </Col>
        </FormGroup>
      );
    } else {
      return (
        <FormGroup row>
          <Label for={obj.label} sm={2}>
            {obj.label}
          </Label>
          <Col sm={10}>
            {this.state.mode === "show" ? (
              <div className="user-values">{renderProfile[obj.label]}</div>
            ) : (
              <Input
                type="number"
                name={obj.label}
                id={obj.id}
                placeholder={obj.placeHolder}
                defaultValue={parseInt(renderProfile[obj.label])}
                onChange={e => this.handleInputChange(e, obj)}
              />
            )}
          </Col>
        </FormGroup>
      );
    }
  };

  buildUserProfile = () => {
    let items = userFormMetaData.map(obj => {
      if (obj.category === "basic") {
        return this.getFormInput(obj);
      }
    });
    return items;
  };

  buildAccordian = type => {
    let headerInfo =
      type === "company" ? "Company & contact" : "Language & Region";
    let items = userFormMetaData.map(obj => {
      if (obj.category === type) {
        return this.getFormInput(obj);
      }
    });
    let accordian = (
      <Accordion defaultActiveKey="0">
        <Card>
          <Accordion.Toggle as={Card.Header} eventKey="0">
            <div className="accrodian-header">
              <h4>
                {type === "company" ? (
                  <FaUserAlt size={24} />
                ) : (
                  <FaGlobeAmericas size={24} />
                )}{" "}
                &nbsp;{headerInfo}
              </h4>
              <div className="action-icon">
                <FaChevronDown />
              </div>
            </div>
          </Accordion.Toggle>
          <Accordion.Collapse eventKey="0">
            <Card.Body>{items}</Card.Body>
          </Accordion.Collapse>
        </Card>
      </Accordion>
    );
    return accordian;
  };

  shouldComponentUpdate(nextProps, nextState) {

    if (nextProps.userDetails.id !== this.state.userDetails.id) {
      return true;
    }
    if(nextState.mode !== this.state.mode){
        return true;
    }
    return false;
  }

  updateView =()=>{
      console.log("inside update..")
      this.setState({mode:'edit'})
  }
  profileAction = ()=>{
    console.log("cuurent",this.props)
    this.props.addProfileActions(this.state.answers,this.state.mode,this.state.userDetails["id"]) 
  }

  render() {
      console.log("inside render")
    this.state.updateAnswers && this.buildAnswers();
    let userProfile = this.buildUserProfile();
    let userDetails = this.state.userDetails;
    let companyAccordian = this.buildAccordian("company");
    let languageAccordian = this.buildAccordian("language");
    console.log("insde render user details",userDetails)
    return (
      <div className="container profile-details-wrapper">
        <div className="user-header-action">
          <div className="user-name-details">
            {this.props.mode === "create" ? (
              <h3>New User</h3>
            ) : (
              <React.Fragment>
                <h3>{userDetails.Name}</h3>
                <h5>{userDetails.Email}</h5>
              </React.Fragment>
            )}
          </div>
          <div className="user-operations">
            {this.state.mode === "show" ? (
              <div onClick={this.updateView}><FaPen size={32}/></div>
            ) : (
              <React.Fragment>
                <FaTimesCircle size={32} />
                <div onClick={this.profileAction}><FaCheckCircle size={32} /></div>
              </React.Fragment>
            )}
          </div>
        </div>
        <div className="user-basic-info">
          <div className="avatar">
            <img src="/img/12.png" alt="image missing" />
          </div>
          <div className="details">{userProfile}</div>
        </div>
        <div>
          {companyAccordian}
          {languageAccordian}
        </div>
      </div>
    );
  }
}
