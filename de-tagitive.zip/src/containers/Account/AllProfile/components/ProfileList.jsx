import React, { Component } from "react";
import ProfileItem from "./ProfileItem.jsx";

export default class ProfileList extends Component {
    constructor () {
        super()
    
        // this.renderMap = this.renderMap.bind(this);
        // this.handleClick = this.handleClick.bind(this);
      }
  render() {
    let profiles = this.props.profileList;
    const trItem = profiles.map((item, index) => (
        <ProfileItem
            key={index}
            profile={item}
            index={index}
            editProfileSubmit={this.props.editProfileSubmit}
            deleteProfile={this.props.deleteProfile}
            selectedProfile={this.props.selectedProfile}
            
        />
    ));
    return <tbody>{trItem}</tbody>;
  }
}
