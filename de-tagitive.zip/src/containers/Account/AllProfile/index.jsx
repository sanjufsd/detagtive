import React from "react";
import { Container } from "reactstrap";
import ProfileTasks from "./components/ProfileTasks";
import Profiles from './components/Profiles';
const UserProfiles = () => (
      <Profiles />
);

export default UserProfiles;
